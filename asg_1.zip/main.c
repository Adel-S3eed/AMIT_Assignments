#include<stdio.h>

int main()

{
    printf("Welcome to the even/odd check program \n*************************************\n");
    
    while(1)
    
    {

    int Number,reference;

    printf("Add your number please\t");
    scanf(" \n %d",&Number);


    reference = Number/2;
    
    if( Number == reference*2 )
    printf("The number is even = 1 \nThe number is odd = 0\n**********************\n");

    else  
    printf("The number is odd = 1\nThe number is even = 0\n**********************\n");
    
    }
    
return 0;

}