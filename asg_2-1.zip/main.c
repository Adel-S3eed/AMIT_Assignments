#include <math.h>
#include <stdio.h>

int main()
{
    int num;
    int digit, counter, result = 0;
    
    printf("please enter a number: ");
    scanf("%d", &num);
    
    int num2 = num, num3 = num;
    
    for(counter = 0; num2; counter++, num2 /= 10);
    
    while(num3) 
    {
        
        digit = num3 % 10;
        result += pow(digit, counter);
        num3 /= 10;
        
    };
    
    if(result == num)
    
        printf("this is an armstrong number");
    else
        printf("this is not an armstrong number");
        
    
    return 0;
    
}    