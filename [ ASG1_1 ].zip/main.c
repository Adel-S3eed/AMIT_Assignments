#include <math.h>
#include <stdio.h>

int main()

{
    printf("Welcome to ‘‘ Decimal to Binary converter ’’ program\n");
    printf("****************************************************\n");
    

    int num, reminder, result=0;
    
    printf("please enter a number: ");
    scanf("%d",&num);
    
    for(int count=0 ;num; count++) 
    
    {
        reminder = num % 2;
        result  += reminder * (pow(10, count));
        num     /= 2;
        
    };
    
    printf("%d",result);
    return 0;
    
}