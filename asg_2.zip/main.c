#include <math.h>
#include <stdio.h>


 int main()
 
 {
     
     printf("Welcome to our simple Calculator  \n");
     printf("********************************\n ");
     
     
     float number1,number2,Result;
     char Operation;
     
     
     printf("Choose the operator(+ or - or * or /): \n");
     scanf("%c",&Operation);

     printf("Add your first number please: \t");
     scanf("%f",&number1);
    
     printf("Add your second number please: \t");
     scanf("%f",&number2);
     

    switch(Operation)
    
    {
        
      case '+':
      Result=number1+number2;
      printf("%f",Result); 
        break;
        
      case '-':
        Result=number1-number2;
        printf("%f",Result); 
        break;
        
      case '*':
        Result=number1*number2;
        printf("%f ",Result); 
        break;
        
      case '/':
        Result=number1/number2;
        printf("%f ",Result); 
        break;
        
       default:
        printf("Wrong operator!!");
        
     }

     return 0;
    
 }