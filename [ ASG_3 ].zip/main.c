#include<stdio.h>  
  
void swapping(int num1, int num2);  
  
int main()  

{  
    printf("Welcome to our Swapping program \n");
    printf("******************************* \n");
    
    int x, y;  
  
    printf("Enter first value\n");  
    scanf("%d", &x);  
    
    printf("Enter second value\n");  
    scanf("%d", &y);  
  
    printf("\n\nBefore swapping: x = %d and y = %d \n", x, y);  
  
    swapping(x, y);  
  
    return 0;  
}  
  
void swapping(int x, int y)  

{  
    int temp;  
  
    temp = x;  
    x    = y;  
    y    = temp;  
    printf("After swapping: x = %d and y = %d \n", x, y);  
}  